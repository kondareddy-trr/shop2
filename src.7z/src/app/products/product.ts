export interface prod{
    "imageUrl":string;
    "productName":string;
    "productPrice":number;
    "description":string;
    "features":string;
    "starRating":number;
    "productId":number;
    
}
