import{ Component } from '@angular/core';
import{prod} from './product';
import { Router } from '@angular/router';
@Component({
   selector:'pm-products',
   templateUrl:'../Products/products.component.html'
})

export class ProductsComponent
{
    products(productid)
        {
let id=productid;   
switch(id)
{
    case 1:
    alert("Samsung 40 inch 4K is added to cart");
    break;
    case 2:
    alert(" LG 43LH576T Smart TV is added to cart");
    break;
    case 3:
    alert("Samsung S7 Edge+ is added to cart");
    break;
    case 4:
    alert("LG  V 30+ is added to cart");
    break;
    case 5:
    alert("HP Laptop is added to cart");
    break;
    case 6:
    alert("Lenovo Thinkpad is added to cart");
    break;
    case 7:
    alert("Apple ipad is added to cart");
    break;
    case 8:
    alert("SAMSUNG Galaxy Tab S2 9.7” Tablet is added to cart");
    break;
    
}
        }
    head:string="flipkart products";
    product1: prod[] = [
         {
            "productId":1,
            "imageUrl": "https://www.richersounds.com/media/catalog/product/cache/c687aa7517cf01e65c009f6943c2b1e9/4/0/400033-v2.jpg",
            "productName": "Samsung 40 inch 4K",
            "productPrice": 102999,
            "description": "Samsung UE40MU6120 40 inch 4K Ultra HD Smart HDR LED TV TVPlus,Certified Ultra HD",
            "features":"HDR, Smart view, Smart hub, Gaming, UHD upscaling",
            "starRating": 4.2,
            
        }
    ];
    product2: prod[] = [
        {
            "productId":2,
            "imageUrl": "https://www.lg.com/in/images/tvs/md05608284/gallery/11Large-940x620.jpg",
            "productName": "LG 43LH576T Smart TV",
            "productPrice": 89999,
            "description": "LG Full HD TVs with resolution of 1920 X 1080 pixels provides you with an outstandingly detailed and crisp pictures. The 2 million pixels spread across screen provide real life like picture with utmost clarity.",
            "features":"Full HD 1080p, Smart TV, Miracast , Netflix, Youtube, Built in Wifi",
            "starRating": 4.4,
        }
    ];
    product3: prod []=[
        {
            "productId":3,
            "imageUrl":"https://www.91-img.com/pictures/89993-v1-samsung-galaxy-s7-edge-mobile-phone-large-1.jpg",
            "productName":"Samsung S7 Edge+",
            "productPrice":35000,
            "description":"The Samsung Galaxy S7 Edge is a monster in terms of specs and features and with 3D glass and metal body it combines beauty too. Additional features such as dust and waterproof make it a perfect choice. Along with Samsung Galaxy S7, it boasts of being the first phones to come with dual pixel camera as well.",
            "features":"Supports Indian bands, 32 GB + 200 GB Expandable, Waterproof, IP68, Fingerprint sensor",
            "starRating":4.5,
        }];
product4: prod[] = [
         {
             "productId":4,
            "imageUrl":"https://www.lg.com/hk_en/images/mobile-phone/md05885198/gallery/H930DS-Aurora-Black-128GB_Desk1_171009.jpg",
            "productName":"LG  V 30+",
            "productPrice":25000,
            "description":"LG V30+ H930DS Aurora Black 128GB",
            "features":"Sturdy and Seamless, Hold Less, Let There Be Light,Be Your Own Director, Total Zoom Control, Capture the Bigger Picture",
            "starRating":4.7,
         }
   ];
   product5:  prod []=[
        {
            "productId":5,
            "imageUrl":"https://4.imimg.com/data4/FX/SL/MY-10150834/laptops-computer-500x500.jpg",
            "productName":"HP Laptop",
            "productPrice":34000,
            "description":"We are remarkable enterprise, involved in offering superior quality HP Laptop.",
            "features":"Durability, Reliability, Premium quality",
            "starRating":4.2,
        }];
    product6: prod[] = [
         {
             "productId":6,
            "imageUrl":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRxAOPo_FeTCr9ky9MGhlYGaYwvOcwiZdWrGXn69t0ohkStBGL3",
            "productName":"Lenovo Thinkpad",
            "productPrice":60000,
            "description":"ThinkPad X1 Yoga are pretty much similar to the hardware used for the ThinkPad X1 Carbon — Intel’s quad-core Core i5/i7 processors with integrated UHD Graphics 620, up to 16 GB of LPDDR3-2133 memory, up to 1 TB SSD.",
            "features":"1920×1080 IPS 2560×1440 IPS with Dolby Vision HDR Touchscreens on select SKUs",
            "starRating":4.7,
         }
   ];
   product7:  prod []=[
        {
            "productId":7,
            "imageUrl":"https://i5.walmartimages.com/asr/d77b32ee-66fa-48d3-bd3c-b9b24a496483_1.78997456599888c8d59bf7aa18af2fab.jpeg?odnHeight=450&odnWidth=450&odnBg=FFFFFF",
            "productName":"Apple ipad",
            "productPrice":65000,
            "description":"Create, learn, work, and play like never before. Featuring an immersive 9.7-inch Multi-Touch Retina display,¹ powerful A10 Fusion chip, and now supports Apple Pencil,² there's nothing else quite like iPad.",
            "features":"Apple iPad (Latest Model) with Wi-Fi - 32GB, Lightning to USB Cable, USB Power Adapter",
            "starRating":4.7,
        }];
    product8: prod[] = [
         {
             "productId":8,
            "imageUrl":"https://brain-images-ssl.cdn.dixons.com/7/6/10137667/u_10137667.jpg",
            "productName":"SAMSUNG Galaxy Tab S2 9.7” Tablet",
            "productPrice":25000,
            "description":"Samsung's thinnest and lightest tablet ever, Super AMOLED screen delivers vibrant, incredibly detailed visuals, Powerful processor and 3 GB of RAM make for fast, responsive tablet computing, Microsoft Office for Android lets you create and edit documents just like you would on a PC",
            "features":"Lightweight, portable design",
            "starRating":4.3,
         }
   ];
    
    imageWidth:number=100;
    imageMargin:number=20;
}