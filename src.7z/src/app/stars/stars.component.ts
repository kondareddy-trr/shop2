import {Component, Input, Output, EventEmitter, OnChanges} from '@angular/core';
import {ProductsComponent} from '../products/products.component'
@Component({
    selector:'ai-star',
    templateUrl:'../stars/stars.component.html',
    styleUrls:['../stars/stars.component.css']
})

export class StarsComponent implements OnChanges
{
    @Input() rating:number;
    starWidth:number;
    
    @Output() ratingClicked: EventEmitter<string>=
    new EventEmitter<string>();

    ngOnChanges():void{
        this.starWidth=this.rating*86/5;
    }  
}